<?php


	$conexion= new mysqli("localhost", "root", "", "sistema");


		if ($conexion->connect_errno){

			echo "fallo la conexion" . $conexion->connect_errno;


		}

		$conexion->set_charset("utf8");

		$sql = "SELECT * FROM USUARIOS";

		$resultado = $conexion->query($sql);

		if ($conexion->errno) {

			die($conexion->error);
			
		}

			while ($fila=$resultado->fetch_assoc()) {
				

				echo $fila['ID'] . " ";
				echo $fila['USUARIO'] . " ";
				echo $fila['NOMBRE'] . " ";
				echo $fila['APELLIDO'] . " ";

				echo "<br>";
				
				 

			}

				$conexion->close();


?>