<?php

if (isset($_SESSION['usuario'])) {
	header("Location:index.php");
}

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Login Sistema</title>
</head>

<body>

	<center>
		<h4>Bienvenido</h4>
	<form action="login.php" method="post">
		
		 <h4> Usuario <input type="text" name="usuario"> </h3>
		 	<h4>Contraseña <input type="text" name="clave"></h4>
		 	<input type="submit" name="enviar" value="enviar">

		</center>



	</form>


		<?php
		$conexion = new mysqli("localhost","root","","sistema");

		if (isset($_POST['enviar'])) {

			$user = $_POST['usuario'];
			$pass = $_POST['clave'];


			$sql = "SELECT * FROM USUARIOS WHERE USUARIO = '$user'";
			$res = $conexion->query($sql);

			if ($res->num_rows > 0) {

				while ($row = $res->fetch_assoc()){

					$pass2 = $row['CLAVE'];

					/*if (password_verify($pass, $pass2)){

						session_start();

						$_SESSION['usuario'] = $user;
						$_SESSION['id'] = $row['ID'];
						$_SESSION['name'] = $row['NOMBRE'];


							header("Location:index.php");
					}else{
						echo "¡Error al iniciar sesion!";
					}*/
						header("Location:index.php");

				}
			}else{
						echo "¡Error al iniciar sesion!</div></div>";
			}
		}
		?>
</body>
</html>